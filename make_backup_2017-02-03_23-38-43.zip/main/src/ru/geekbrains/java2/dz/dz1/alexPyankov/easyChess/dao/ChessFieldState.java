package ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao;

/**
 * Created by alex on 03.02.17.
 */
public class ChessFieldState {
}
