package ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao;

import ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao.implementation.ChessField;

/**
 * @author Alexander Pyankov
 * @version Alpha
 */
public interface Movements {
    void move (String moveTo);
    boolean checkMove (String moveTo);
    boolean checkAttack (ChessField field);
}
