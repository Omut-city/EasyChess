package ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao.implementation;

import ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao.ChessMan;
import ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao.Color;
import ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao.State;

/**
 * Created by alex on 03.02.17.
 */
public class ChessField {
    private Color color;
    private State state;
    private ChessMan figure;

    public ChessField() {
    }

    public ChessField(Color color, State state) {
        this.color = color;
        this.state = state;
        this.figure = null;

    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public ChessMan getFigure() {
        return figure;
    }

    public void setFigure(ChessMan figure) {
        this.figure = figure;
    }

}
