package ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.application;

import ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao.implementation.ChessBoard;

/**
 * Created by alex on 03.02.17.
 */
public class Game {

    public static void main(String [] args) {
        ChessBoard board = ChessBoard.getInstance();
        System.out.println(board);
        board.printBoardState();
        board.printBoard();




    }



}
