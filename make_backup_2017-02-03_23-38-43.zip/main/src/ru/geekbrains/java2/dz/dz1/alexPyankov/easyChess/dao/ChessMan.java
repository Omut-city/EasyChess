package ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao;

import ru.geekbrains.java2.dz.dz1.alexPyankov.easyChess.dao.implementation.ChessField;

import java.net.CookieHandler;

/**
 * @author Alexander Pyankov
 * @version Alpha
 */
public abstract class ChessMan implements Movements {
    private ChessField currentPosition;
    private Color team;
    private String name;
    private String typeName;

    public ChessMan () {
    }

    public ChessMan (ChessField startPosition, String name, Color team) {
        this.currentPosition = startPosition;
        this.name = name;
        this.team = team;
    }

    public Color getTeam() {
        return team;
    }

    public void setTeam(Color team) {
        this.team = team;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public ChessField getCurrentPosition() {
        return currentPosition;
    }

    public void setCurrentPosition(ChessField currentPosition) {
        this.currentPosition = currentPosition;
    }
}

